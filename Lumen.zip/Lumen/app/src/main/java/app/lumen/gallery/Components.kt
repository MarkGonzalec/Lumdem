package app.lumen.gallery

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.PhotoAlbum
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest

// ---------- Thumbnails ----------

@Composable
fun Thumb(item: MediaItem, modifier: Modifier = Modifier, size: Int = 360) {
    val ctx = LocalContext.current
    val request = remember(item.id, size) {
        ImageRequest.Builder(ctx).data(item.uri).size(size).build()
    }
    AsyncImage(
        model = request,
        contentDescription = null,
        contentScale = ContentScale.Crop,
        modifier = modifier.background(MaterialTheme.colorScheme.surfaceVariant),
    )
}

/** Мозаика обложки альбома: 0–4 фото. */
@Composable
fun Collage(items: List<MediaItem>, modifier: Modifier = Modifier, radius: Dp = 18.dp) {
    val gap = 2.dp
    Box(
        modifier
            .clip(RoundedCornerShape(radius))
            .background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center,
    ) {
        when (items.size) {
            0 -> Icon(
                Icons.Rounded.PhotoLibrary, null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.45f),
                modifier = Modifier.fillMaxSize(0.3f),
            )
            1 -> Thumb(items[0], Modifier.fillMaxSize(), 600)
            2 -> Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(gap)) {
                Thumb(items[0], Modifier.weight(1f).fillMaxHeight())
                Thumb(items[1], Modifier.weight(1f).fillMaxHeight())
            }
            3 -> Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(gap)) {
                Thumb(items[0], Modifier.weight(1f).fillMaxHeight())
                Column(
                    Modifier.weight(1f).fillMaxHeight(),
                    verticalArrangement = Arrangement.spacedBy(gap),
                ) {
                    Thumb(items[1], Modifier.weight(1f).fillMaxWidth())
                    Thumb(items[2], Modifier.weight(1f).fillMaxWidth())
                }
            }
            else -> Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(gap)) {
                Row(
                    Modifier.weight(1f).fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(gap),
                ) {
                    Thumb(items[0], Modifier.weight(1f).fillMaxHeight())
                    Thumb(items[1], Modifier.weight(1f).fillMaxHeight())
                }
                Row(
                    Modifier.weight(1f).fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(gap),
                ) {
                    Thumb(items[2], Modifier.weight(1f).fillMaxHeight())
                    Thumb(items[3], Modifier.weight(1f).fillMaxHeight())
                }
            }
        }
    }
}

// ---------- Grid ----------

@Composable
fun DayHeader(text: String) {
    Text(
        text,
        fontSize = 17.sp,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 18.dp, bottom = 8.dp),
    )
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun Cell(
    m: MediaItem,
    selecting: Boolean,
    selected: Boolean,
    fav: Boolean,
    onClick: () -> Unit,
    onLong: () -> Unit,
) {
    val scale by animateFloatAsState(if (selected) 0.86f else 1f, label = "scale")
    val radius by animateDpAsState(if (selected) 12.dp else 0.dp, label = "radius")
    Box(Modifier.aspectRatio(1f).combinedClickable(onClick = onClick, onLongClick = onLong)) {
        Thumb(
            m,
            Modifier.fillMaxSize().graphicsLayer {
                scaleX = scale
                scaleY = scale
                shape = RoundedCornerShape(radius)
                clip = true
            },
        )
        if (m.isVideo) {
            Row(
                Modifier
                    .align(Alignment.BottomEnd)
                    .padding(6.dp)
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.5f))
                    .padding(horizontal = 6.dp, vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Rounded.PlayArrow, null, tint = Color.White, modifier = Modifier.size(12.dp))
                Text(durationLabel(m.durationMs), color = Color.White, fontSize = 11.sp)
            }
        }
        if (fav && !selecting) {
            Icon(
                Icons.Rounded.Favorite, null,
                tint = Color.White,
                modifier = Modifier.align(Alignment.BottomStart).padding(6.dp).size(14.dp),
            )
        }
        if (selecting) {
            Box(
                Modifier
                    .align(Alignment.TopEnd)
                    .padding(8.dp)
                    .size(22.dp)
                    .clip(CircleShape)
                    .background(if (selected) MaterialTheme.colorScheme.primary else Color.Black.copy(alpha = 0.25f))
                    .border(1.5.dp, Color.White, CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                if (selected) Icon(Icons.Rounded.Check, null, tint = Color.White, modifier = Modifier.size(15.dp))
            }
        }
    }
}

@Composable
fun MediaGrid(
    media: List<MediaItem>,
    grouped: Boolean,
    columns: Int,
    selecting: Boolean,
    selected: Set<Long>,
    favorites: Set<Long>,
    onOpen: (Int) -> Unit,
    onToggle: (Long) -> Unit,
    onLongPress: (Long) -> Unit,
    modifier: Modifier = Modifier,
    bottomPadding: Dp = 120.dp,
    header: @Composable () -> Unit = {},
) {
    val groups = remember(media, grouped) {
        if (grouped) media.withIndex().groupBy { dayKey(it.value.dateMs) }.values.toList()
        else emptyList()
    }
    LazyVerticalGrid(
        columns = GridCells.Fixed(columns),
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = bottomPadding),
        horizontalArrangement = Arrangement.spacedBy(2.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        item(key = "header", span = { GridItemSpan(maxLineSpan) }) { header() }
        if (grouped) {
            groups.forEach { g ->
                val first = g.first().value
                item(key = "d${dayKey(first.dateMs)}", span = { GridItemSpan(maxLineSpan) }) {
                    DayHeader(dayLabel(first.dateMs))
                }
                items(g, key = { "m${it.value.id}" }) { iv ->
                    val m = iv.value
                    Cell(
                        m, selecting, m.id in selected, m.id in favorites,
                        onClick = { if (selecting) onToggle(m.id) else onOpen(iv.index) },
                        onLong = { onLongPress(m.id) },
                    )
                }
            }
        } else {
            items(media.size, key = { "m${media[it].id}" }) { i ->
                val m = media[i]
                Cell(
                    m, selecting, m.id in selected, m.id in favorites,
                    onClick = { if (selecting) onToggle(m.id) else onOpen(i) },
                    onLong = { onLongPress(m.id) },
                )
            }
        }
    }
}

// ---------- Buttons & bars ----------

@Composable
fun PillButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    filled: Boolean = false,
    enabled: Boolean = true,
) {
    val bg = if (filled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
    val fg = if (filled) Color.White else MaterialTheme.colorScheme.primary
    val a = if (enabled) 1f else 0.45f
    Box(
        modifier
            .clip(CircleShape)
            .background(bg.copy(alpha = a))
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 9.dp),
    ) {
        Text(text, color = fg.copy(alpha = a), fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun GlassButton(icon: ImageVector, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier
            .size(40.dp)
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(22.dp))
    }
}

@Composable
fun Segmented(options: List<String>, selected: Int, onSelect: (Int) -> Unit, modifier: Modifier = Modifier) {
    Row(
        modifier
            .clip(RoundedCornerShape(10.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(2.dp),
    ) {
        options.forEachIndexed { i, t ->
            val sel = i == selected
            val bg by animateColorAsState(
                if (sel) MaterialTheme.colorScheme.background else Color.Transparent,
                label = "seg",
            )
            Box(
                Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(8.dp))
                    .background(bg)
                    .clickable { onSelect(i) }
                    .padding(vertical = 6.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(t, fontSize = 13.sp, fontWeight = if (sel) FontWeight.SemiBold else FontWeight.Medium)
            }
        }
    }
}

@Composable
fun FloatingPill(modifier: Modifier = Modifier, content: @Composable RowScope.() -> Unit) {
    Surface(
        modifier,
        shape = CircleShape,
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.95f),
        shadowElevation = 14.dp,
        border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f)),
    ) {
        Row(Modifier.padding(6.dp), verticalAlignment = Alignment.CenterVertically, content = content)
    }
}

@Composable
private fun PillTab(icon: ImageVector, label: String, selected: Boolean, onClick: () -> Unit) {
    val primary = MaterialTheme.colorScheme.primary
    val bg by animateColorAsState(if (selected) primary.copy(alpha = 0.14f) else Color.Transparent, label = "tabBg")
    val fg by animateColorAsState(
        if (selected) primary else MaterialTheme.colorScheme.onSurfaceVariant,
        label = "tabFg",
    )
    Column(
        Modifier
            .clip(CircleShape)
            .background(bg)
            .clickable(onClick = onClick)
            .padding(horizontal = 22.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, null, tint = fg, modifier = Modifier.size(26.dp))
        Text(label, color = fg, fontSize = 11.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun TabBar(tab: Int, onTab: (Int) -> Unit, modifier: Modifier = Modifier) {
    FloatingPill(modifier.navigationBarsPadding().padding(bottom = 12.dp)) {
        PillTab(Icons.Rounded.PhotoLibrary, "Библиотека", tab == 0) { onTab(0) }
        PillTab(Icons.Rounded.PhotoAlbum, "Альбомы", tab == 1) { onTab(1) }
    }
}

data class Act(val icon: ImageVector, val label: String, val onClick: () -> Unit)

@Composable
private fun ActionItem(act: Act, enabled: Boolean) {
    val fg = MaterialTheme.colorScheme.primary.copy(alpha = if (enabled) 1f else 0.4f)
    Column(
        Modifier
            .clip(CircleShape)
            .clickable(enabled = enabled, onClick = act.onClick)
            .padding(horizontal = 18.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(act.icon, null, tint = fg, modifier = Modifier.size(26.dp))
        Text(act.label, color = fg, fontSize = 11.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun BoxScope.SelectionOverlay(count: Int, onCancel: () -> Unit, actions: List<Act>) {
    Surface(
        Modifier.align(Alignment.TopCenter).fillMaxWidth(),
        color = MaterialTheme.colorScheme.background.copy(alpha = 0.94f),
    ) {
        Row(
            Modifier.statusBarsPadding().padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            PillButton("Отмена", onCancel)
            Text(
                if (count == 0) "Выберите элементы" else "Выбрано: $count",
                Modifier.weight(1f),
                textAlign = TextAlign.Center,
                fontWeight = FontWeight.SemiBold,
                fontSize = 17.sp,
            )
            Spacer(Modifier.width(80.dp))
        }
    }
    FloatingPill(
        Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 12.dp),
    ) {
        actions.forEach { ActionItem(it, enabled = count > 0) }
    }
}

// ---------- Add to album sheet ----------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddToAlbumSheet(
    albums: List<AlbumUi>,
    onPick: (AlbumUi) -> Unit,
    onNew: () -> Unit,
    onDismiss: () -> Unit,
) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Text(
            "Добавить в альбом",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
        )
        LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
            item(key = "new") {
                Row(
                    Modifier.fillMaxWidth().clickable(onClick = onNew).padding(horizontal = 20.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(
                        Modifier
                            .size(56.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(Icons.Rounded.Add, null, tint = MaterialTheme.colorScheme.primary)
                    }
                    Spacer(Modifier.width(14.dp))
                    Text(
                        "Новый альбом",
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 16.sp,
                    )
                }
            }
            items(albums, key = { it.id }) { a ->
                Row(
                    Modifier.fillMaxWidth().clickable { onPick(a) }.padding(horizontal = 20.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Collage(a.media.take(4), Modifier.size(56.dp), radius = 12.dp)
                    Spacer(Modifier.width(14.dp))
                    Column {
                        Text(a.name, fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("${a.media.size} фото", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}
