package app.lumen.gallery

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

// ---------- Room ----------

@Entity(tableName = "albums")
data class AlbumEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val createdAt: Long = System.currentTimeMillis(),
)

@Entity(
    tableName = "album_items",
    primaryKeys = ["albumId", "mediaId"],
    indices = [Index("mediaId")],
    foreignKeys = [
        ForeignKey(
            entity = AlbumEntity::class,
            parentColumns = ["id"],
            childColumns = ["albumId"],
            onDelete = ForeignKey.CASCADE,
        ),
    ],
)
data class AlbumItemEntity(
    val albumId: Long,
    val mediaId: Long,
    val addedAt: Long = System.currentTimeMillis(),
)

@Entity(tableName = "favorites")
data class FavoriteEntity(@PrimaryKey val mediaId: Long)

@Dao
interface GalleryDao {
    @Query("SELECT * FROM albums ORDER BY createdAt DESC")
    fun albums(): Flow<List<AlbumEntity>>

    @Query("SELECT * FROM album_items")
    fun allItems(): Flow<List<AlbumItemEntity>>

    @Query("SELECT mediaId FROM favorites")
    fun favorites(): Flow<List<Long>>

    @Insert
    suspend fun insertAlbum(album: AlbumEntity): Long

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun addItems(items: List<AlbumItemEntity>)

    @Query("DELETE FROM album_items WHERE albumId = :albumId AND mediaId IN (:ids)")
    suspend fun removeItems(albumId: Long, ids: List<Long>)

    @Query("UPDATE albums SET name = :name WHERE id = :id")
    suspend fun rename(id: Long, name: String)

    @Query("DELETE FROM albums WHERE id = :id")
    suspend fun deleteAlbum(id: Long)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun addFavorites(items: List<FavoriteEntity>)

    @Query("DELETE FROM favorites WHERE mediaId IN (:ids)")
    suspend fun removeFavorites(ids: List<Long>)
}

@Database(
    entities = [AlbumEntity::class, AlbumItemEntity::class, FavoriteEntity::class],
    version = 1,
    exportSchema = false,
)
abstract class GalleryDb : RoomDatabase() {
    abstract fun dao(): GalleryDao

    companion object {
        fun create(context: Context): GalleryDb =
            Room.databaseBuilder(context.applicationContext, GalleryDb::class.java, "lumen.db").build()
    }
}

// ---------- MediaStore ----------

data class MediaItem(
    val id: Long,
    val uri: Uri,
    val dateMs: Long,
    val isVideo: Boolean,
    val durationMs: Long,
)

class MediaRepo(private val context: Context) {
    suspend fun load(): List<MediaItem> = withContext(Dispatchers.IO) {
        val out = ArrayList<MediaItem>()
        val projection = arrayOf(
            MediaStore.Files.FileColumns._ID,
            MediaStore.Files.FileColumns.MEDIA_TYPE,
            MediaStore.MediaColumns.DATE_TAKEN,
            MediaStore.MediaColumns.DATE_ADDED,
            MediaStore.MediaColumns.DURATION,
        )
        val selection = "${MediaStore.Files.FileColumns.MEDIA_TYPE} IN (?, ?)"
        val args = arrayOf(
            MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE.toString(),
            MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO.toString(),
        )
        context.contentResolver.query(
            MediaStore.Files.getContentUri("external"), projection, selection, args, null,
        )?.use { c ->
            val iId = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns._ID)
            val iType = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.MEDIA_TYPE)
            val iTaken = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_TAKEN)
            val iAdded = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_ADDED)
            val iDur = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DURATION)
            while (c.moveToNext()) {
                val id = c.getLong(iId)
                val video = c.getInt(iType) == MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO
                var date = c.getLong(iTaken)
                if (date <= 0L) date = c.getLong(iAdded) * 1000L
                val base = if (video) MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                out += MediaItem(
                    id = id,
                    uri = ContentUris.withAppendedId(base, id),
                    dateMs = date,
                    isVideo = video,
                    durationMs = if (video) c.getLong(iDur) else 0L,
                )
            }
        }
        out.sortByDescending { it.dateMs }
        out
    }
}
