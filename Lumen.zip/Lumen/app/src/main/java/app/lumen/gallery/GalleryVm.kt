package app.lumen.gallery

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class AlbumUi(val id: Long, val name: String, val media: List<MediaItem>)

class GalleryVm(app: Application) : AndroidViewModel(app) {
    private val dao = GalleryDb.create(app).dao()
    private val repo = MediaRepo(app)

    val media = MutableStateFlow<List<MediaItem>>(emptyList())
    val loaded = MutableStateFlow(false)

    val favorites: StateFlow<Set<Long>> = dao.favorites()
        .map { it.toSet() }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptySet())

    val albums: StateFlow<List<AlbumUi>> =
        combine(dao.albums(), dao.allItems(), media) { albums, items, all ->
            val byId = all.associateBy { it.id }
            val grouped = items.groupBy { it.albumId }
            albums.map { a ->
                AlbumUi(
                    id = a.id,
                    name = a.name,
                    media = grouped[a.id].orEmpty()
                        .mapNotNull { byId[it.mediaId] }
                        .sortedByDescending { it.dateMs },
                )
            }
        }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    fun refresh() {
        viewModelScope.launch {
            media.value = repo.load()
            loaded.value = true
        }
    }

    fun createAlbum(name: String, ids: List<Long>) {
        viewModelScope.launch {
            val id = dao.insertAlbum(AlbumEntity(name = name.trim()))
            dao.addItems(ids.map { AlbumItemEntity(id, it) })
        }
    }

    fun addToAlbum(albumId: Long, ids: Collection<Long>) {
        viewModelScope.launch { dao.addItems(ids.map { AlbumItemEntity(albumId, it) }) }
    }

    fun removeFromAlbum(albumId: Long, ids: Collection<Long>) {
        viewModelScope.launch { dao.removeItems(albumId, ids.toList()) }
    }

    fun rename(albumId: Long, name: String) {
        viewModelScope.launch { dao.rename(albumId, name.trim()) }
    }

    fun deleteAlbum(albumId: Long) {
        viewModelScope.launch { dao.deleteAlbum(albumId) }
    }

    fun setFavorite(ids: Collection<Long>, fav: Boolean) {
        viewModelScope.launch {
            if (fav) dao.addFavorites(ids.map { FavoriteEntity(it) })
            else dao.removeFavorites(ids.toList())
        }
    }

    fun toggleFavorite(id: Long) {
        setFavorite(listOf(id), id !in favorites.value)
    }
}
