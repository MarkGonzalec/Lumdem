package app.lumen.gallery

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            LumenTheme {
                Root()
            }
        }
    }
}

private fun hasAccess(ctx: Context): Boolean =
    ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_MEDIA_IMAGES) ==
        PackageManager.PERMISSION_GRANTED

@Composable
fun Root(vm: GalleryVm = viewModel()) {
    val ctx = LocalContext.current
    var granted by remember { mutableStateOf(hasAccess(ctx)) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        granted = hasAccess(ctx)
        if (granted) vm.refresh()
    }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        granted = hasAccess(ctx)
        if (granted) vm.refresh()
    }
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        if (granted) {
            App(vm)
        } else {
            PermissionScreen(
                onAllow = {
                    launcher.launch(
                        arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO),
                    )
                },
                onSettings = {
                    ctx.startActivity(
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}")),
                    )
                },
            )
        }
    }
}

@Composable
private fun PermissionScreen(onAllow: () -> Unit, onSettings: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center,
    ) {
        Box(
            Modifier.size(96.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Rounded.PhotoLibrary, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(48.dp))
        }
        Spacer(Modifier.height(24.dp))
        Text("Доступ к фото", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(8.dp))
        Text(
            "Lumen показывает ваши фото и видео прямо с телефона. Ничего не отправляется в интернет.",
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(28.dp))
        PillButton("Разрешить доступ", onAllow, filled = true)
        Spacer(Modifier.height(12.dp))
        PillButton("Открыть настройки", onSettings)
    }
}

// ---------- Navigation ----------

sealed interface Screen {
    data class Album(val ref: AlbumRef) : Screen
    data class Create(val pre: List<Long>) : Screen
    data class Pick(val albumId: Long) : Screen
}

private class AlbumRequest(val ids: List<Long>, val done: () -> Unit)

@Composable
fun App(vm: GalleryVm) {
    var stack by remember { mutableStateOf<List<Screen>>(emptyList()) }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var selecting by remember { mutableStateOf(false) }
    var viewer by remember { mutableStateOf<ViewerState?>(null) }
    var request by remember { mutableStateOf<AlbumRequest?>(null) }
    val lastViewer = remember { arrayOfNulls<ViewerState>(1) }
    if (viewer != null) lastViewer[0] = viewer

    val albums by vm.albums.collectAsStateWithLifecycle()
    val favs by vm.favorites.collectAsStateWithLifecycle()

    fun push(s: Screen) { stack = stack + s }
    fun pop() { stack = stack.dropLast(1) }

    BackHandler(enabled = stack.isNotEmpty()) { pop() }

    val openViewer: (List<MediaItem>, Int) -> Unit = { list, i -> viewer = ViewerState(list, i) }
    val requestAlbum: (List<Long>, () -> Unit) -> Unit = { ids, done -> request = AlbumRequest(ids, done) }

    Box(Modifier.fillMaxSize()) {
        // Базовый слой: вкладки
        Box(Modifier.fillMaxSize()) {
            if (tab == 0) {
                LibraryScreen(vm, openViewer, requestAlbum) { selecting = it }
            } else {
                AlbumsScreen(
                    vm,
                    open = { push(Screen.Album(it)) },
                    create = { push(Screen.Create(emptyList())) },
                )
            }
            if (!selecting) {
                TabBar(tab, { tab = it }, Modifier.align(Alignment.BottomCenter))
            }
        }

        // Экраны поверх вкладок
        AnimatedContent(
            targetState = stack.lastOrNull(),
            modifier = Modifier.fillMaxSize(),
            transitionSpec = {
                when {
                    initialState == null && targetState != null ->
                        (slideInHorizontally(tween(280)) { it } + fadeIn(tween(200))) togetherWith fadeOut(tween(200))
                    targetState == null ->
                        fadeIn(tween(200)) togetherWith (slideOutHorizontally(tween(260)) { it } + fadeOut(tween(200)))
                    else -> fadeIn(tween(200)) togetherWith fadeOut(tween(150))
                }
            },
            label = "screens",
        ) { s ->
            when (s) {
                null -> Box(Modifier.fillMaxSize())
                is Screen.Album -> Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
                    AlbumDetailScreen(
                        vm = vm,
                        ref = s.ref,
                        onBack = { pop() },
                        openViewer = openViewer,
                        addPhotos = { push(Screen.Pick(it)) },
                        requestAlbum = requestAlbum,
                    )
                }
                is Screen.Create -> PickerScreen(
                    vm = vm,
                    title = "Новый альбом",
                    confirm = "Готово",
                    withName = true,
                    preselect = s.pre,
                    exclude = emptySet(),
                    onClose = { pop() },
                    onConfirm = { name, ids ->
                        vm.createAlbum(name, ids)
                        pop()
                    },
                )
                is Screen.Pick -> PickerScreen(
                    vm = vm,
                    title = "Добавить фото",
                    confirm = "Добавить",
                    withName = false,
                    preselect = emptyList(),
                    exclude = albums.firstOrNull { it.id == s.albumId }?.media?.map { it.id }?.toSet().orEmpty(),
                    onClose = { pop() },
                    onConfirm = { _, ids ->
                        vm.addToAlbum(s.albumId, ids)
                        pop()
                    },
                )
            }
        }

        // Просмотрщик
        AnimatedVisibility(
            visible = viewer != null,
            enter = fadeIn(tween(180)) + scaleIn(tween(220), initialScale = 0.92f),
            exit = fadeOut(tween(150)),
        ) {
            lastViewer[0]?.let { v ->
                Viewer(
                    items = v.items,
                    start = v.index,
                    favorites = favs,
                    onClose = { viewer = null },
                    onFavorite = { vm.toggleFavorite(it) },
                    onAddToAlbum = { request = AlbumRequest(listOf(it.id)) {} },
                )
            }
        }
    }

    request?.let { r ->
        AddToAlbumSheet(
            albums = albums,
            onPick = {
                vm.addToAlbum(it.id, r.ids)
                r.done()
                request = null
            },
            onNew = {
                request = null
                viewer = null
                r.done()
                push(Screen.Create(r.ids))
            },
            onDismiss = { request = null },
        )
    }
}
