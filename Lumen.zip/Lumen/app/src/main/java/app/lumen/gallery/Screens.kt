package app.lumen.gallery

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ChevronLeft
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.MoreHoriz
import androidx.compose.material.icons.rounded.PhotoAlbum
import androidx.compose.material.icons.rounded.RemoveCircleOutline
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle

sealed interface AlbumRef {
    data class User(val id: Long) : AlbumRef
    data object Favorites : AlbumRef
    data object Videos : AlbumRef
}

private fun selectionActions(
    vm: GalleryVm,
    selected: Set<Long>,
    favs: Set<Long>,
    exit: () -> Unit,
    requestAlbum: (List<Long>, () -> Unit) -> Unit,
    extra: List<Act> = emptyList(),
): List<Act> {
    val allFav = selected.isNotEmpty() && selected.all { it in favs }
    return listOf(
        Act(Icons.Rounded.PhotoAlbum, "В альбом") { requestAlbum(selected.toList(), exit) },
        Act(
            if (allFav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
            if (allFav) "Из избранного" else "В избранное",
        ) {
            vm.setFavorite(selected, !allFav)
            exit()
        },
    ) + extra
}

// ---------- Library ----------

@Composable
fun LibraryScreen(
    vm: GalleryVm,
    openViewer: (List<MediaItem>, Int) -> Unit,
    requestAlbum: (List<Long>, () -> Unit) -> Unit,
    onSelecting: (Boolean) -> Unit,
) {
    val media by vm.media.collectAsStateWithLifecycle()
    val favs by vm.favorites.collectAsStateWithLifecycle()
    val loaded by vm.loaded.collectAsStateWithLifecycle()
    var mode by rememberSaveable { mutableIntStateOf(0) }
    var selecting by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf(setOf<Long>()) }
    val top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()

    fun exit() {
        selecting = false
        selected = emptySet()
    }
    androidx.compose.runtime.LaunchedEffect(selecting) { onSelecting(selecting) }
    BackHandler(selecting) { exit() }

    Box(Modifier.fillMaxSize()) {
        MediaGrid(
            media = media,
            grouped = mode == 0,
            columns = if (mode == 0) 3 else 4,
            selecting = selecting,
            selected = selected,
            favorites = favs,
            onOpen = { openViewer(media, it) },
            onToggle = { id -> selected = if (id in selected) selected - id else selected + id },
            onLongPress = { id ->
                selecting = true
                selected = selected + id
            },
        ) {
            Column(Modifier.padding(start = 16.dp, end = 16.dp, top = top + 12.dp, bottom = 10.dp)) {
                Row(verticalAlignment = Alignment.Bottom) {
                    Column(Modifier.weight(1f)) {
                        Text("Библиотека", fontSize = 34.sp, fontWeight = FontWeight.ExtraBold)
                        Text(
                            "${media.count { !it.isVideo }} фото · ${media.count { it.isVideo }} видео",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 14.sp,
                        )
                    }
                    PillButton("Выбрать", { selecting = true }, enabled = media.isNotEmpty())
                }
                Spacer(Modifier.height(12.dp))
                Segmented(listOf("Дни", "Все"), mode, { mode = it }, Modifier.width(160.dp))
                if (loaded && media.isEmpty()) {
                    Text(
                        "Фото и видео пока не найдены",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 40.dp),
                    )
                }
            }
        }
        if (selecting) {
            SelectionOverlay(
                count = selected.size,
                onCancel = { exit() },
                actions = selectionActions(vm, selected, favs, { exit() }, requestAlbum),
            )
        }
    }
}

// ---------- Albums ----------

@Composable
private fun SectionTitle(text: String) {
    Text(text, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
}

@Composable
private fun AlbumCard(name: String, media: List<MediaItem>, onClick: () -> Unit) {
    Column(Modifier.clip(RoundedCornerShape(18.dp)).clickable(onClick = onClick)) {
        Collage(media.take(4), Modifier.fillMaxWidth().aspectRatio(1f))
        Text(
            name,
            fontSize = 15.sp,
            fontWeight = FontWeight.Medium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 8.dp),
        )
        Text("${media.size}", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun NewAlbumCard(onClick: () -> Unit) {
    val primary = MaterialTheme.colorScheme.primary
    Column {
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .clip(RoundedCornerShape(18.dp))
                .background(primary.copy(alpha = 0.10f))
                .border(1.5.dp, primary.copy(alpha = 0.35f), RoundedCornerShape(18.dp))
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center,
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Rounded.Add, null, tint = primary, modifier = Modifier.size(38.dp))
                Text("Новый альбом", color = primary, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            }
        }
    }
}

@Composable
fun AlbumsScreen(vm: GalleryVm, open: (AlbumRef) -> Unit, create: () -> Unit) {
    val albums by vm.albums.collectAsStateWithLifecycle()
    val media by vm.media.collectAsStateWithLifecycle()
    val favs by vm.favorites.collectAsStateWithLifecycle()
    val top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val favMedia = remember(media, favs) { media.filter { it.id in favs } }
    val videos = remember(media) { media.filter { it.isVideo } }

    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = top + 12.dp, bottom = 120.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Text("Альбомы", fontSize = 34.sp, fontWeight = FontWeight.ExtraBold)
        }
        item(span = { GridItemSpan(maxLineSpan) }) { SectionTitle("Мои альбомы") }
        item { NewAlbumCard(create) }
        items(albums, key = { "a${it.id}" }) { a ->
            AlbumCard(a.name, a.media) { open(AlbumRef.User(a.id)) }
        }
        item(span = { GridItemSpan(maxLineSpan) }) { SectionTitle("Подборки") }
        item { AlbumCard("Избранное", favMedia) { open(AlbumRef.Favorites) } }
        item { AlbumCard("Видео", videos) { open(AlbumRef.Videos) } }
    }
}

// ---------- Album detail ----------

@Composable
fun AlbumDetailScreen(
    vm: GalleryVm,
    ref: AlbumRef,
    onBack: () -> Unit,
    openViewer: (List<MediaItem>, Int) -> Unit,
    addPhotos: (Long) -> Unit,
    requestAlbum: (List<Long>, () -> Unit) -> Unit,
) {
    val media by vm.media.collectAsStateWithLifecycle()
    val favs by vm.favorites.collectAsStateWithLifecycle()
    val albums by vm.albums.collectAsStateWithLifecycle()
    val top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()

    val userAlbum = (ref as? AlbumRef.User)?.let { r -> albums.firstOrNull { it.id == r.id } }
    val items = when (ref) {
        is AlbumRef.User -> userAlbum?.media.orEmpty()
        AlbumRef.Favorites -> media.filter { it.id in favs }
        AlbumRef.Videos -> media.filter { it.isVideo }
    }
    val title = when (ref) {
        is AlbumRef.User -> userAlbum?.name.orEmpty()
        AlbumRef.Favorites -> "Избранное"
        AlbumRef.Videos -> "Видео"
    }

    var selecting by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf(setOf<Long>()) }
    var menu by remember { mutableStateOf(false) }
    var renaming by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf(false) }

    fun exit() {
        selecting = false
        selected = emptySet()
    }
    BackHandler(selecting) { exit() }

    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        MediaGrid(
            media = items,
            grouped = false,
            columns = 3,
            selecting = selecting,
            selected = selected,
            favorites = favs,
            onOpen = { openViewer(items, it) },
            onToggle = { id -> selected = if (id in selected) selected - id else selected + id },
            onLongPress = { id ->
                selecting = true
                selected = selected + id
            },
        ) {
            Column(Modifier.padding(start = 16.dp, end = 16.dp, top = top + 8.dp, bottom = 12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    GlassButton(Icons.Rounded.ChevronLeft, onBack)
                    Spacer(Modifier.weight(1f))
                    if (ref is AlbumRef.User) {
                        GlassButton(Icons.Rounded.Add, { addPhotos(ref.id) })
                        Spacer(Modifier.width(8.dp))
                        Box {
                            GlassButton(Icons.Rounded.MoreHoriz, { menu = true })
                            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                                DropdownMenuItem(
                                    text = { Text("Переименовать") },
                                    onClick = { menu = false; renaming = true },
                                )
                                DropdownMenuItem(
                                    text = { Text("Удалить альбом") },
                                    onClick = { menu = false; deleting = true },
                                )
                            }
                        }
                        Spacer(Modifier.width(8.dp))
                    }
                    PillButton("Выбрать", { selecting = true }, enabled = items.isNotEmpty())
                }
                Spacer(Modifier.height(14.dp))
                Text(title, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(
                    "${items.size} элементов",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 14.sp,
                )
                if (items.isEmpty()) {
                    Text(
                        if (ref is AlbumRef.User) "Здесь пока пусто. Нажмите «+», чтобы добавить фото."
                        else "Здесь пока пусто.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 40.dp),
                    )
                }
            }
        }
        if (selecting) {
            val extra = if (ref is AlbumRef.User) {
                listOf(
                    Act(Icons.Rounded.RemoveCircleOutline, "Убрать") {
                        vm.removeFromAlbum(ref.id, selected)
                        exit()
                    },
                )
            } else emptyList()
            SelectionOverlay(
                count = selected.size,
                onCancel = { exit() },
                actions = selectionActions(vm, selected, favs, { exit() }, requestAlbum, extra),
            )
        }
    }

    if (renaming && ref is AlbumRef.User) {
        var text by remember { mutableStateOf(title) }
        AlertDialog(
            onDismissRequest = { renaming = false },
            title = { Text("Название альбома") },
            text = { OutlinedTextField(text, { text = it }, singleLine = true) },
            confirmButton = {
                TextButton(onClick = {
                    if (text.isNotBlank()) vm.rename(ref.id, text)
                    renaming = false
                }) { Text("Готово") }
            },
            dismissButton = { TextButton(onClick = { renaming = false }) { Text("Отмена") } },
        )
    }
    if (deleting && ref is AlbumRef.User) {
        AlertDialog(
            onDismissRequest = { deleting = false },
            title = { Text("Удалить альбом?") },
            text = { Text("Сами фото останутся в библиотеке.") },
            confirmButton = {
                TextButton(onClick = {
                    deleting = false
                    vm.deleteAlbum(ref.id)
                    onBack()
                }) { Text("Удалить", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { deleting = false }) { Text("Отмена") } },
        )
    }
}

// ---------- Picker (create album / add photos) ----------

@Composable
fun PickerScreen(
    vm: GalleryVm,
    title: String,
    confirm: String,
    withName: Boolean,
    preselect: List<Long>,
    exclude: Set<Long>,
    onClose: () -> Unit,
    onConfirm: (String, List<Long>) -> Unit,
) {
    val media by vm.media.collectAsStateWithLifecycle()
    val list = remember(media, exclude) { media.filter { it.id !in exclude } }
    val byId = remember(list) { list.associateBy { it.id } }
    val order = remember { mutableStateListOf<Long>().also { it.addAll(preselect) } }
    var name by rememberSaveable { mutableStateOf("") }
    val top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val ok = (!withName || name.isNotBlank()) && (withName || order.isNotEmpty())

    fun toggle(id: Long) {
        if (!order.remove(id)) order.add(id)
    }

    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        MediaGrid(
            media = list,
            grouped = false,
            columns = 4,
            selecting = true,
            selected = order.toSet(),
            favorites = emptySet(),
            onOpen = { toggle(list[it].id) },
            onToggle = { toggle(it) },
            onLongPress = {},
            bottomPadding = 40.dp,
        ) {
            Column(
                Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = top + 68.dp, bottom = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                if (withName) {
                    Collage(order.mapNotNull { byId[it] }.take(4), Modifier.size(170.dp), radius = 24.dp)
                    Spacer(Modifier.height(16.dp))
                    BasicTextField(
                        value = name,
                        onValueChange = { if (it.length <= 40) name = it },
                        singleLine = true,
                        textStyle = TextStyle(
                            fontSize = 26.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center,
                            color = MaterialTheme.colorScheme.onBackground,
                        ),
                        cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                        modifier = Modifier.fillMaxWidth(),
                        decorationBox = { inner ->
                            Box(contentAlignment = Alignment.Center) {
                                if (name.isEmpty()) {
                                    Text(
                                        "Название альбома",
                                        fontSize = 26.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                                    )
                                }
                                inner()
                            }
                        },
                    )
                }
                Text(
                    if (order.isEmpty()) "Выберите фото" else "Выбрано: ${order.size}",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 14.sp,
                    modifier = Modifier.padding(top = 8.dp),
                )
            }
        }
        Surface(
            Modifier.align(Alignment.TopCenter).fillMaxWidth(),
            color = MaterialTheme.colorScheme.background.copy(alpha = 0.94f),
        ) {
            Row(
                Modifier.statusBarsPadding().padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                PillButton("Отмена", onClose)
                Text(
                    title,
                    Modifier.weight(1f),
                    textAlign = TextAlign.Center,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 17.sp,
                )
                PillButton(confirm, { onConfirm(name, order.toList()) }, filled = true, enabled = ok)
            }
        }
    }
}
