package app.lumen.gallery

import android.content.Context
import android.content.Intent
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

private val RU: Locale = Locale.forLanguageTag("ru")

private fun localDate(ms: Long): LocalDate =
    Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()).toLocalDate()

fun dayKey(ms: Long): Long = localDate(ms).toEpochDay()

fun dayLabel(ms: Long): String {
    val d = localDate(ms)
    val now = LocalDate.now()
    return when {
        d == now -> "Сегодня"
        d == now.minusDays(1) -> "Вчера"
        d.year == now.year -> d.format(DateTimeFormatter.ofPattern("d MMMM, EEEE", RU))
        else -> d.format(DateTimeFormatter.ofPattern("d MMMM yyyy", RU))
    }
}

fun timeLabel(ms: Long): String =
    Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault())
        .format(DateTimeFormatter.ofPattern("HH:mm", RU))

fun durationLabel(ms: Long): String {
    val s = ms / 1000
    return "%d:%02d".format(s / 60, s % 60)
}

fun Context.share(item: MediaItem) {
    val send = Intent(Intent.ACTION_SEND).apply {
        type = if (item.isVideo) "video/*" else "image/*"
        putExtra(Intent.EXTRA_STREAM, item.uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    runCatching { startActivity(Intent.createChooser(send, null)) }
}

fun Context.playVideo(item: MediaItem) {
    val view = Intent(Intent.ACTION_VIEW).apply {
        setDataAndType(item.uri, "video/*")
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    runCatching { startActivity(view) }
}
